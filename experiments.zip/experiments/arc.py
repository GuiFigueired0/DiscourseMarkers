'''
Old file from src that runs an experiment on the ARC datasets.
Won't work on its own.
'''

import argparse
import os
import torch
import csv
import numpy as np
import pandas as pd
from torch.utils.data import DataLoader, ConcatDataset
from models import DynamicMultiTaskModel
from trainer import MultiTaskTrainer
from batch_sampler import BalancedBatchSampler
from data_processor import DataProcessor, collate_fn
from sklearn.utils.class_weight import compute_class_weight

DEFAULT_CONFIG = {
    'model_name': 'roberta-base',
    'max_length': 512,
    'batch_size': 64,
    'lr': 1e-5,
    'weight_decay': 0.01,
    'epochs': 30,
    'early_stopping': 5,
    'dm_csv_path': './../data/dm_en.csv',
    'results_file': './results/arc_results.csv',
    'model_dir': './saved_models'
}

# Class Weights from Paper (Table 3 Setup)
# SE: 1:10 (Support:Attack) -> [1.0, 10.0]
# DB: 1:1 -> [1.0, 1.0]
# M-ARG: 9.375 : 30 : 1 (Support:Attack:Neutral) -> Mapped to IDs [9.375, 30.0, 1.0]
ARC_CLASS_WEIGHTS = {
    'student_essay': [1.0, 10.0],
    'debate': [1.0, 1.0],
    'm-arg': [9.375, 30.0, 1.0]
}

def get_class_weights(dataset):
    labels = dataset.labels
    classes = np.unique(labels)
    weights = compute_class_weight(class_weight='balanced', classes=classes, y=labels)
    return torch.tensor(weights, dtype=torch.float)

def log_to_csv(filename, data_dict):
    file_exists = os.path.isfile(filename)
    with open(filename, mode='a', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=data_dict.keys())
        if not file_exists:
            writer.writeheader()
        writer.writerow(data_dict)

def run_arc_experiment(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    config = DEFAULT_CONFIG.copy()

    if args.mode in ['baseline', 'transfer']:
        betas_to_search = [0.0]
    else:
        betas_to_search = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]

    processor = DataProcessor(config)

    print(f"--- Preparing Data for {args.dataset} ---")

    ext = 'txt'
    file_prefix = 'essay' if args.dataset == 'student_essay' else 'debate_concept'
    path_train = f"./data/{args.dataset}/train_{file_prefix}.{ext}"
    path_test = f"./data/{args.dataset}/test_{file_prefix}.{ext}"
    path_dev = f"./data/{args.dataset}/dev_{file_prefix}.{ext}"

    ds_arc_train = processor.get_arc_dataset(args.dataset, path_train)
    ds_arc_dev = processor.get_arc_dataset(args.dataset, path_dev)
    ds_arc_test = processor.get_arc_dataset(args.dataset, path_test)

    ds_dm_train, ds_dm_test = processor.get_dm_partition(config['dm_csv_path'])

    for beta in betas_to_search:
        print(f"\n" + "=" * 40)
        print(f"Running Experiment: Dataset={args.dataset} | Mode={args.mode} | Beta={beta}")
        print("=" * 40)

        model = DynamicMultiTaskModel(config)

        if args.mode == 'transfer':
            print(">> Loading Pre-trained DM Weights...")
            model.add_task_head('dm', 4)
            dm_path = os.path.join(config['model_dir'], 'best_dm_model.pt')

            if os.path.exists(dm_path):
                model.load_state_dict(torch.load(dm_path, map_location=device))
                print(">> Weights loaded successfully.")
            else:
                print(f"!! WARNING: {dm_path} not found. Training from scratch !!")

        num_labels_arc = len(ARC_CLASS_WEIGHTS[args.dataset])
        model.add_task_head('arc', num_labels_arc)

        if 'dm' not in model.heads:
            model.add_task_head('dm', 4)

        model.to(device)

        w_arc = torch.tensor(ARC_CLASS_WEIGHTS[args.dataset], dtype=torch.float)
        w_dm = get_class_weights(ds_dm_train)

        class_weights_dict = {'arc': w_arc, 'dm': w_dm}

        if args.mode == 'mtl' and beta > 0:
            # MTL: ARC + DM
            sampler = BalancedBatchSampler(ds_arc_train, ds_dm_train, config['batch_size'])
            combined = ConcatDataset([ds_arc_train, ds_dm_train])
            train_loader = DataLoader(combined, batch_sampler=sampler, collate_fn=collate_fn)
            task_mode = 'mixed'
        else:
            # Baseline or Transfer (Single Task)
            train_loader = DataLoader(ds_arc_train, batch_size=config['batch_size'], shuffle=True, collate_fn=collate_fn)
            task_mode = 'arc'

        trainer_config = {
            'primary': 'arc', 'secondary': 'dm',
            'weights': {'arc': 1.0, 'dm': beta}
        }
        trainer = MultiTaskTrainer(model, config, device, trainer_config, class_weights=class_weights_dict)

        best_dev_f1 = 0.0
        best_test_metrics = {'acc': 0.0, 'f1': 0.0}

        for epoch in range(config['epochs']):
            train_loss = trainer.train_epoch(train_loader, epoch + 1, task_mode=task_mode)

            dev_acc, dev_f1 = trainer.evaluate(DataLoader(ds_arc_dev, batch_size=32, collate_fn=collate_fn), 'arc')
            print(f"  Ep {epoch + 1} | Loss: {train_loss:.4f} | Dev F1: {dev_f1:.4f}")

            if dev_f1 > best_dev_f1:
                best_dev_f1 = dev_f1
                test_acc, test_f1 = trainer.evaluate(DataLoader(ds_arc_test, batch_size=32, collate_fn=collate_fn), 'arc')
                best_test_metrics = {'acc': test_acc, 'f1': test_f1}
                print(f"  >>> New Best Found! Test F1: {test_f1:.4f}")

        result_entry = {
            'dataset': args.dataset,
            'mode': args.mode,
            'beta': beta,
            'best_dev_f1': best_dev_f1,
            'test_acc': best_test_metrics['acc'],
            'test_f1': best_test_metrics['f1']
        }
        log_to_csv(config['results_file'], result_entry)
        print(f"Results saved to {config['results_file']}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, required=True, choices=['student_essay', 'debate', 'm-arg'])
    parser.add_argument('--mode', type=str, default='mtl', choices=['mtl', 'baseline', 'transfer'])
    args = parser.parse_args()

    run_arc_experiment(args)