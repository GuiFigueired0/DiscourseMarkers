'''
Old file from src that runs a grid search experiment on the anli dataset.
Won't work on its own.
'''

import argparse
import os
import torch
import numpy as np
from torch.utils.data import DataLoader, ConcatDataset
from sklearn.utils.class_weight import compute_class_weight

from models import DynamicMultiTaskModel
from trainer import MultiTaskTrainer
from batch_sampler import BalancedBatchSampler
from data_processor import DataProcessor, collate_fn

CONFIG = {
    'model_name': 'roberta-base',
    'batch_size': 32,
    'epochs': 10,
    'dm_csv_path': './../data/dm_en.csv',
    'model_dir': './saved_models',
    'early_stopping': 2
}

GRID_SPACE = {
    'lrs': [1e-5, 2e-5, 5e-5],
    'dm_weights': [0.2, 0.5, 0.8, 1.0]
}

def get_class_weights(dataset):
    labels = dataset.labels
    classes = np.unique(labels)
    weights = compute_class_weight(class_weight='balanced', classes=classes, y=labels)
    return torch.tensor(weights, dtype=torch.float)

def run_experiment(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    processor = DataProcessor(CONFIG)

    prev_model_path = None
    if args.step > 0:
        prev_step_name = f"{args.mode}_step{args.step - 1}.pt"
        prev_model_path = os.path.join(CONFIG['model_dir'], prev_step_name)

    # Determine Grid parameters
    search_lrs = GRID_SPACE['lrs'] if args.grid_search else [2e-5]
    search_dm_weights = GRID_SPACE['dm_weights'] if args.grid_search else [0.5]

    global_best_acc = 0.0
    best_params = {}

    for lr in search_lrs:
        for dm_w in search_dm_weights:
            print(f"\n" + "=" * 40)
            print(f"RUNNING CONFIG: LR={lr}, DM_WEIGHT={dm_w}")
            print("=" * 40)

            # Re-init Model and Load checkpont for every parameter set
            model = DynamicMultiTaskModel(CONFIG)
            model.add_task_head('anli', 3)
            model.add_task_head('dm', 4)
            model.to(device)

            if prev_model_path and os.path.exists(prev_model_path):
                model.load_state_dict(torch.load(prev_model_path, map_location=device))

            # Update local config for this run
            current_config = CONFIG.copy()
            current_config['lr'] = lr

            # 2. Prepare Data & Trainer
            task_weights_tensors = None
            test_ds = None
            is_dm_pre_training = False

            if args.mode == 'mtl':
                ds_anli = processor.get_anli_dataset(split=f'train_r{args.step}')
                ds_dm, _ = processor.get_dm_partition(CONFIG['dm_csv_path'])
                dm_weights = get_class_weights(ds_dm)
                task_weights_tensors = {'dm': dm_weights}

                sampler = BalancedBatchSampler(ds_anli, ds_dm, CONFIG['batch_size'])
                combined = ConcatDataset([ds_anli, ds_dm])
                train_loader = DataLoader(combined, batch_sampler=sampler, collate_fn=collate_fn)
                task_mode = 'mixed'
            else:
                # Step 0: Pre-training on DM (Only for Transfer mode)
                if args.mode == 'transfer' and args.step == 0:
                    print("Setup: Training on Discourse Markers (DM)")
                    ds_train, test_ds = processor.get_dm_partition(CONFIG['dm_csv_path'])
                    dm_weights = get_class_weights(ds_train)
                    task_weights = {'dm': dm_weights}
                    task_mode = 'dm'
                    is_dm_pre_training = True

                # Step 1, 2, 3: ANLI Rounds
                else:
                    round_key = f"train_r{args.step}"  # e.g., train_r1
                    print(f"Setup: Training on ANLI {round_key}")
                    ds_train = processor.get_anli_dataset(split=round_key)
                    task_mode = 'anli'

                train_loader = DataLoader(ds_train, batch_size=CONFIG['batch_size'], shuffle=True,
                                          collate_fn=collate_fn)

            if test_ds is None:
                test_ds = processor.get_anli_dataset(split=f'test_r{args.step}')
            _, dm_test = processor.get_dm_partition(CONFIG['dm_csv_path'])

            trainer_config = {
                'primary': 'anli', 'secondary': 'dm',
                'weights': {'anli': 1.0, 'dm': dm_w}
            }
            trainer = MultiTaskTrainer(model, current_config, device, trainer_config,
                                       class_weights=task_weights_tensors)

            # 3. Training Loop
            best_run_acc = 0.0
            best_epoch = -1

            for epoch in range(current_config['epochs']):
                if epoch - best_epoch > current_config['early_stopping']:
                    break

                loss = trainer.train_epoch(train_loader, epoch + 1, task_mode=task_mode)
                acc, _ = trainer.evaluate(DataLoader(test_ds, batch_size=32, collate_fn=collate_fn), 'anli')

                print(f"Epoch {epoch + 1} -> Loss: {loss:.4f} | Acc: {acc:.4f}")

                if acc > best_run_acc:
                    best_epoch = epoch
                    best_run_acc = acc
                    # Global best tracking
                    if acc > global_best_acc:
                        global_best_acc = acc
                        best_params = {'lr': lr, 'dm_w': dm_w}
                        save_name = f"best_grid_{args.mode}_step{args.step}.pt"
                        torch.save(model.state_dict(), os.path.join(CONFIG['model_dir'], save_name))

    print(f"\nGRID SEARCH COMPLETE")
    print(f"Best Accuracy: {global_best_acc:.4f} with Params: {best_params}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', type=str, choices=['mtl', 'baseline', 'transfer'], required=True)
    parser.add_argument('--step', type=int, default=1)
    parser.add_argument('--grid_search', action='store_true', help="Enable grid search over parameters")
    args = parser.parse_args()
    run_experiment(args)

